import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { finalize } from 'rxjs/operators';
import { TimersApiService } from '../core/api/timers-api.service';
import { Timer } from '../core/models/timer.model';

@Injectable({ providedIn: 'root' })
export class TimersStore {
  private readonly timers$ = new BehaviorSubject<Timer[]>([]);
  private readonly loading$ = new BehaviorSubject<boolean>(false);

  constructor(private api: TimersApiService) {}

  load(): void {
    this.loading$.next(true);
    this.api.getAll()
      .pipe(finalize(() => this.loading$.next(false)))
      .subscribe(timers => this.timers$.next(timers));
  }

  getTimers$(): Observable<Timer[]> {
    return this.timers$.asObservable();
  }

  getLoading$(): Observable<boolean> {
    return this.loading$.asObservable();
  }

  delete(id: string): void {
    this.api.delete(id).subscribe(() => {
      this.timers$.next(this.timers$.value.filter(t => t.name !== id));
    });
  }

  suspend(ids: string[]): void {
    this.api.suspend(ids).subscribe(() => this.load());
  }

  resume(ids: string[]): void {
    this.api.resume(ids).subscribe(() => this.load());
  }

  trigger(ids: string[]): void {
    this.api.trigger(ids).subscribe(() => this.load());
  }
}
