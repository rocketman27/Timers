export interface Timer {
  name: string;
  timeZone: string;
  triggerTime: string;
  filterCondition: FilterCondition;
  publishTime: string;
  active: boolean;
}

export interface FilterCondition {
  regions: string[];
  subregions: string[];
  countries: string[];
  productTypes: string[];
  bookingModels: string[];
  flowTypes: string[];
}
