import { Component, OnInit } from '@angular/core';
import { ColDef } from 'ag-grid-community';
import { TimersStore } from '../../state/timers.store';
import { Timer } from '../../core/models/timer.model';

@Component({
  selector: 'app-timers',
  templateUrl: './timers.component.html',
  styleUrls: ['./timers.component.scss']
})
export class TimersComponent implements OnInit {
  timers$ = this.store.getTimers$();
  loading$ = this.store.getLoading$();

  columnDefs: ColDef<Timer>[] = [
    { field: 'name', headerName: 'Name' },
    { field: 'timeZone', headerName: 'Time Zone' },
    { field: 'triggerTime', headerName: 'Trigger Time' },
    { field: 'publishTime', headerName: 'Publish Time' },
    { field: 'active', headerName: 'Active', valueFormatter: p => p.value ? 'Yes' : 'No' }
  ];

  constructor(private store: TimersStore) {}

  ngOnInit(): void {
    this.store.load();
  }

  onDeleteSelected(): void {
    // Example: delete logic can be wired to context menu or button
  }
}
