export const environment = {
  production: false,
  // Base URL for the REST API. In dev, this is proxied by proxy.conf.json
  apiBaseUrl: '/api'
};
