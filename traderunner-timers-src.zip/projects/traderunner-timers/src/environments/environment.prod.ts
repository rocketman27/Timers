export const environment = {
  production: true,
  // Set this to your production API base URL (no dev proxy).
  apiBaseUrl: 'https://your-prod-domain.example.com/api'
};
