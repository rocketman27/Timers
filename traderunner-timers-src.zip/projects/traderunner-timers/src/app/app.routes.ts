import { Routes } from '@angular/router';
import { TimersComponent } from './components/timers/timers.component';

export const routes: Routes = [
  { path: '', pathMatch: 'full', redirectTo: 'timers' },
  { path: 'timers', component: TimersComponent }
];
