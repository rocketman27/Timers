export interface FilterCondition {
  regions: string[];
  subregions: string[];
  countries: string[];
  productTypes: string[];
  bookingModels: string[];
  flowTypes: string[];
  // Add other filter fields as needed
}

export interface Timer {
  name: string;
  timeZone: string;
  triggerTime: string;        // e.g. cron or HH:mm
  filterCondition: FilterCondition;
  publishTime?: string | null; // ISO string (LocalDateTime from backend)
  isActive: boolean;
}
