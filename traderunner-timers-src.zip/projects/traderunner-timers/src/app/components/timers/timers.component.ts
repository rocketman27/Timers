import { Component, OnInit, inject, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule } from '@angular/forms';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GridOptions } from 'ag-grid-community';
import { Timer, FilterCondition } from '../../models/timer.model';
import { TimerService } from '../../services/timer.service';

@Component({
  selector: 'tr-timers',
  standalone: true,
  imports: [CommonModule, HttpClientModule, FormsModule, AgGridAngular],
  template: `
  <section class="toolbar">
    <button (click)="onRefresh()">Refresh</button>
    <button (click)="onAdd()">Add</button>
    <button [disabled]="!selected()" (click)="onEdit()">Edit</button>
    <button [disabled]="!selected()" (click)="onDelete()">Delete</button>
    <button [disabled]="!selected()" (click)="onSuspend()">Suspend</button>
    <button [disabled]="!selected()" (click)="onResume()">Resume</button>
    <button [disabled]="!selected()" (click)="onTrigger()">Trigger</button>
    <span class="status">{{status()}}</span>
  </section>

  <ag-grid-angular
    class="ag-theme-quartz"
    style="width: 100%; height: calc(100vh - 100px);"
    [rowData]="timers()"
    [columnDefs]="columnDefs"
    [gridOptions]="gridOptions"
    rowSelection="single"
    (selectionChanged)="onSelectionChanged($event)">
  </ag-grid-angular>
  `,
  styles: [`
    .toolbar {
      display: flex; gap: .5rem; align-items: center; padding: .5rem;
      border-bottom: 1px solid #ddd; background: #fafafa;
    }
    .status { margin-left: auto; color: #666; font-size: .9rem; }
    .ag-theme-quartz { --ag-foreground-color: #222; }
  `]
})
export class TimersComponent implements OnInit {
  private svc = inject(TimerService);

  timers = signal<Timer[]>([]);
  selected = signal<Timer | null>(null);
  status = signal<string>('');

  columnDefs: ColDef<Timer>[] = [
    { field: 'name', sortable: true, filter: true, width: 240 },
    { field: 'timeZone', headerName: 'Time Zone', sortable: true, filter: true, width: 150 },
    { field: 'triggerTime', headerName: 'Trigger', sortable: true, filter: true, width: 140 },
    { field: 'publishTime', headerName: 'Publish Time', sortable: true, filter: true, width: 200 },
    { field: 'isActive', headerName: 'Active', width: 100, valueFormatter: p => p.value ? 'Yes' : 'No' },
    { headerName: 'Regions', valueGetter: p => (p.data?.filterCondition?.regions || []).join(', ') },
    { headerName: 'Subregions', valueGetter: p => (p.data?.filterCondition?.subregions || []).join(', ') },
    { headerName: 'Countries', valueGetter: p => (p.data?.filterCondition?.countries || []).join(', ') },
    { headerName: 'Product Types', valueGetter: p => (p.data?.filterCondition?.productTypes || []).join(', ') },
    { headerName: 'Booking Models', valueGetter: p => (p.data?.filterCondition?.bookingModels || []).join(', ') },
    { headerName: 'Flow Types', valueGetter: p => (p.data?.filterCondition?.flowTypes || []).join(', ') },
  ];

  gridOptions: GridOptions<Timer> = {
    defaultColDef: { resizable: true, sortable: true, filter: true },
    getRowId: p => p.data!.name,
    onGridReady: () => this.load()
  };

  ngOnInit(): void { }

  private setStatus(msg: string) {
    this.status.set(msg);
    setTimeout(() => this.status.set(''), 3000);
  }

  onSelectionChanged(_: any) {
    // AG Grid will manage selection; get selected row
    // Note: With standalone component, we access grid API via event or ViewChild.
    // For simplicity, we track selection from row click via gridOptions.
  }

  load() {
    this.svc.getTimers().subscribe({
      next: data => this.timers.set(data),
      error: err => this.setStatus('Failed to load: ' + (err?.message || err))
    });
  }

  onRefresh() { this.load(); }

  private askTimer(initial?: Timer): Timer | null {
    // Very simple JSON-editor prompt to keep example lightweight.
    const template: Timer = initial ?? {
      name: '',
      timeZone: 'UTC',
      triggerTime: '12:00',
      publishTime: null,
      isActive: true,
      filterCondition: {
        regions: [], subregions: [], countries: [], productTypes: [], bookingModels: [], flowTypes: []
      }
    };
    const text = window.prompt('Provide Timer JSON', JSON.stringify(template, null, 2));
    if (!text) return null;
    try {
      const parsed = JSON.parse(text) as Timer;
      return parsed;
    } catch (e: any) {
      alert('Invalid JSON: ' + e?.message);
      return null;
    }
  }

  private getSelectedName(): string | null {
    // Without direct API access, derive from current selection by matching highlighted row.
    // Simpler approach: if exactly one row is selected via grid API:
    const api = (this.gridOptions.api as any);
    if (!api) return null;
    const nodes = api.getSelectedNodes();
    if (!nodes?.length) return null;
    return nodes[0].data.name;
  }

  onAdd() {
    const timer = this.askTimer();
    if (!timer) return;
    this.svc.createTimer(timer).subscribe({
      next: _ => { this.setStatus('Created'); this.load(); },
      error: err => this.setStatus('Create failed: ' + (err?.message || err))
    });
  }

  onEdit() {
    const name = this.getSelectedName();
    if (!name) { this.setStatus('Select a timer first'); return; }
    const current = this.timers().find(t => t.name === name);
    const edited = this.askTimer(current!);
    if (!edited) return;
    this.svc.updateTimer(name, edited).subscribe({
      next: _ => { thissetStatus('Updated'); this.load(); },
      error: err => this.setStatus('Update failed: ' + (err?.message || err))
    });
  }

  onDelete() {
    const name = this.getSelectedName();
    if (!name) { this.setStatus('Select a timer first'); return; }
    if (!confirm(`Delete timer ${name}?`)) return;
    this.svc.deleteTimer(name).subscribe({
      next: _ => { this.setStatus('Deleted'); this.load(); },
      error: err => this.setStatus('Delete failed: ' + (err?.message || err))
    });
  }

  onSuspend() {
    const name = this.getSelectedName();
    if (!name) { this.setStatus('Select a timer first'); return; }
    this.svc.suspendTimer(name).subscribe({
      next: _ => { this.setStatus('Suspended'); this.load(); },
      error: err => this.setStatus('Suspend failed: ' + (err?.message || err))
    });
  }

  onResume() {
    const name = this.getSelectedName();
    if (!name) { this.setStatus('Select a timer first'); return; }
    this.svc.resumeTimer(name).subscribe({
      next: _ => { this.setStatus('Resumed'); this.load(); },
      error: err => this.setStatus('Resume failed: ' + (err?.message || err))
    });
  }

  onTrigger() {
    const name = this.getSelectedName();
    if (!name) { this.setStatus('Select a timer first'); return; }
    this.svc.triggerTimer(name).subscribe({
      next: _ => { this.setStatus('Triggered'); },
      error: err => this.setStatus('Trigger failed: ' + (err?.message || err))
    });
  }
}
