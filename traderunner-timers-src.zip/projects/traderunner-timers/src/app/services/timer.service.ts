import { inject, Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { environment } from '../../environments/environment';
import { Timer } from '../models/timer.model';

@Injectable({ providedIn: 'root' })
export class TimerService {
  private http = inject(HttpClient);
  private base = environment.apiBaseUrl.replace(/\/$/, '');
  private resource = `${this.base}/timers`;

  getTimers(): Observable<Timer[]> {
    return this.http.get<Timer[]>(this.resource);
  }

  getTimer(name: string): Observable<Timer> {
    return this.http.get<Timer>(`${this.resource}/${encodeURIComponent(name)}`);
  }

  createTimer(timer: Timer): Observable<Timer> {
    return this.http.post<Timer>(this.resource, timer);
  }

  updateTimer(name: string, timer: Timer): Observable<Timer> {
    return this.http.put<Timer>(`${this.resource}/${encodeURIComponent(name)}`, timer);
  }

  deleteTimer(name: string): Observable<void> {
    return this.http.delete<void>(`${this.resource}/${encodeURIComponent(name)}`);
  }

  suspendTimer(name: string): Observable<void> {
    return this.http.post<void>(`${this.resource}/${encodeURIComponent(name)}/suspend`, {});
  }

  resumeTimer(name: string): Observable<void> {
    return this.http.post<void>(`${this.resource}/${encodeURIComponent(name)}/resume`, {});
  }

  triggerTimer(name: string): Observable<void> {
    return this.http.post<void>(`${this.resource}/${encodeURIComponent(name)}/trigger`, {});
  }

  refreshAll(): Observable<void> {
    return this.http.post<void>(`${this.resource}/refresh`, {});
  }
}
