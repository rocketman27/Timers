import { bootstrapApplication } from '@angular/platform-browser';
import { TimersComponent } from './app/components/timers/timers.component';
import { appConfig } from './app/app.config';

bootstrapApplication(TimersComponent, appConfig)
  .catch(err => console.error(err));
