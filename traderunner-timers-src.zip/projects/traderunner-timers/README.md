# traderunner-timers (Angular 19 + AG Grid 32)

A minimal Angular app that lists and manages timers via a REST API.

## Dev setup

1. Install dependencies:

```bash
npm install
npm install ag-grid-community@32.3.2 ag-grid-angular@32.3.2
```

2. Start the dev server, using the proxy for the backend:

```bash
ng serve --project traderunner-timers --proxy-config projects/traderunner-timers/proxy.conf.json
```

By default, calls are sent to `/api` and proxied to `http://localhost:8080`.

## Production

Set `environment.prod.ts` `apiBaseUrl` to your production API base and build:

```bash
ng build --configuration production
```

## REST endpoints expected

- `GET    /api/timers` → `Timer[]`
- `GET    /api/timers/{name}` → `Timer`
- `POST   /api/timers` (body: `Timer`) → `Timer`
- `PUT    /api/timers/{name}` (body: `Timer`) → `Timer`
- `DELETE /api/timers/{name}`

Extra actions:
- `POST /api/timers/{name}/suspend`
- `POST /api/timers/{name}/resume`
- `POST /api/timers/{name}/trigger`
- `POST /api/timers/refresh`

Adjust paths if your Spring Data REST base path differs.
