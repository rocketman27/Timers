import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef, GridApi, GridReadyEvent } from 'ag-grid-community';
import { TimerService } from '../../services/timer.service';
import { Timer } from '../../models/timer.model';

@Component({
  selector: 'tr-timers',
  standalone: true,
  imports: [CommonModule, AgGridAngular],
  template: `
    <section class="toolbar">
      <button (click)="onRefresh()" [disabled]="!gridApi">Refresh</button>
      <button (click)="onAdd()"     [disabled]="!gridApi">Add</button>
      <button (click)="onEdit()"    [disabled]="!selectedName">Edit</button>
      <button (click)="onDelete()"  [disabled]="!selectedName">Delete</button>
      <button (click)="onSuspend()" [disabled]="!selectedName">Suspend</button>
      <button (click)="onResume()"  [disabled]="!selectedName">Resume</button>
      <button (click)="onTrigger()" [disabled]="!selectedName">Trigger</button>
      <span class="status">{{ status }}</span>
    </section>

    <ag-grid-angular
      class="ag-theme-quartz"
      style="width:100%; height: calc(100vh - 100px);"
      [rowData]="timers"
      [columnDefs]="columnDefs"
      [defaultColDef]="{ resizable: true, sortable: true, filter: true }"
      [getRowId]="getRowId"
      rowSelection="single"
      (gridReady)="onGridReady($event)"
      (selectionChanged)="updateSelection()">
    </ag-grid-angular>
  `,
  styles: [`
    .toolbar { display:flex; gap:.5rem; align-items:center; padding:.5rem; border-bottom:1px solid #ddd; }
    .status { margin-left:auto; color:#666; }
  `]
})
export class TimersComponent {
  timers: Timer[] = [];
  status = '';
  gridApi?: GridApi<Timer>;
  selectedName: string | null = null;

  columnDefs: ColDef<Timer>[] = [
    { field: 'name', width: 220 },
    { field: 'timeZone', headerName: 'Time Zone', width: 150 },
    { field: 'triggerTime', headerName: 'Trigger', width: 130 },
    { field: 'publishTime', headerName: 'Publish Time', width: 200 },
    { field: 'active', headerName: 'Active', valueFormatter: p => p.value ? 'Yes' : 'No', width: 100 },
    { headerName: 'Regions', valueGetter: p => (p.data?.filterCondition?.regions ?? []).join(', ') },
    { headerName: 'Subregions', valueGetter: p => (p.data?.filterCondition?.subregions ?? []).join(', ') },
    { headerName: 'Countries', valueGetter: p => (p.data?.filterCondition?.countries ?? []).join(', ') },
    { headerName: 'Product Types', valueGetter: p => (p.data?.filterCondition?.productTypes ?? []).join(', ') },
    { headerName: 'Booking Models', valueGetter: p => (p.data?.filterCondition?.bookingModels ?? []).join(', ') },
    { headerName: 'Flow Types', valueGetter: p => (p.data?.filterCondition?.flowTypes ?? []).join(', ') },
  ];

  getRowId = (p: { data: Timer }) => p.data.name;

  constructor(private svc: TimerService) {}

  onGridReady(e: GridReadyEvent<Timer>) {
    this.gridApi = e.api;
    this.load();
  }

  updateSelection() {
    if (!this.gridApi) return;
    const node = this.gridApi.getSelectedNodes()[0];
    this.selectedName = node?.data?.name ?? null;
  }

  private setStatus(msg: string) {
    this.status = msg;
    setTimeout(() => this.status = '', 3000);
  }

  load() {
    this.svc.getTimers().subscribe({
      next: timers => {
        this.timers = timers.slice();
        if (this.gridApi && this.selectedName) {
          const row = this.gridApi.getRowNode(this.selectedName);
          if (row) row.setSelected(true);
        }
      },
      error: err => this.setStatus('Failed to load: ' + (err?.message || err))
    });
  }

  onRefresh() { this.load(); }

  onAdd() {
    const newTimer: Timer = {
      name: 'new-timer-' + Date.now(),
      timeZone: 'UTC',
      triggerTime: '12:00:00',
      filterCondition: { regions: [], subregions: [], countries: [], productTypes: [], bookingModels: [], flowTypes: [] },
      publishTime: new Date().toISOString(),
      active: true
    };
    this.svc.addTimer(newTimer).subscribe({
      next: () => { this.setStatus('Timer added'); this.load(); },
      error: err => this.setStatus('Add failed: ' + err.message)
    });
  }

  onEdit() {
    if (!this.selectedName) return;
    this.setStatus('Edit not implemented yet');
  }

  onDelete() {
    if (!this.selectedName) return;
    this.svc.deleteTimer(this.selectedName).subscribe({
      next: () => { this.setStatus('Deleted'); this.load(); },
      error: err => this.setStatus('Delete failed: ' + err.message)
    });
  }

  onSuspend() {
    if (!this.selectedName) return;
    this.svc.suspendTimer(this.selectedName).subscribe({
      next: () => { this.setStatus('Suspended'); this.load(); },
      error: err => this.setStatus('Suspend failed: ' + err.message)
    });
  }

  onResume() {
    if (!this.selectedName) return;
    this.svc.resumeTimer(this.selectedName).subscribe({
      next: () => { this.setStatus('Resumed'); this.load(); },
      error: err => this.setStatus('Resume failed: ' + err.message)
    });
  }

  onTrigger() {
    if (!this.selectedName) return;
    this.svc.triggerTimer(this.selectedName).subscribe({
      next: () => { this.setStatus('Triggered'); this.load(); },
      error: err => this.setStatus('Trigger failed: ' + err.message)
    });
  }
}
