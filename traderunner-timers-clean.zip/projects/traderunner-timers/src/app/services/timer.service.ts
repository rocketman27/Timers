import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Timer } from '../models/timer.model';
import { environment } from '../../environments/environment';

@Injectable({ providedIn: 'root' })
export class TimerService {
  private http = inject(HttpClient);
  private base = (environment.apiBaseUrl || '').replace(/\/$/, '');
  private resource = `${this.base}/timers`;

  getTimers(): Observable<Timer[]> {
    return this.http.get<{ _embedded?: { timers?: Timer[] } }>(this.resource).pipe(
      map(res => res._embedded?.timers ?? [])
    );
  }

  addTimer(timer: Timer): Observable<Timer> {
    return this.http.post<Timer>(this.resource, timer);
  }

  deleteTimer(id: string): Observable<void> {
    return this.http.delete(`${this.resource}/${encodeURIComponent(id)}`, { responseType: 'text' as const })
      .pipe(map(() => void 0));
  }

  suspendTimer(id: string): Observable<void> {
    return this.http.post(`${this.resource}/${encodeURIComponent(id)}/suspend`, {}, { responseType: 'text' as const })
      .pipe(map(() => void 0));
  }

  resumeTimer(id: string): Observable<void> {
    return this.http.post(`${this.resource}/${encodeURIComponent(id)}/resume`, {}, { responseType: 'text' as const })
      .pipe(map(() => void 0));
  }

  triggerTimer(id: string): Observable<void> {
    return this.http.post(`${this.resource}/${encodeURIComponent(id)}/trigger`, {}, { responseType: 'text' as const })
      .pipe(map(() => void 0));
  }
}
