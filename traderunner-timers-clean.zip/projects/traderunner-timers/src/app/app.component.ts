import { Component } from '@angular/core';
import { TimersComponent } from './components/timers/timers.component';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [TimersComponent],
  template: `<tr-timers></tr-timers>`
})
export class AppComponent {}
