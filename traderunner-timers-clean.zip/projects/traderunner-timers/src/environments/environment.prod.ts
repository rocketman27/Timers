export const environment = {
  production: true,
  apiBaseUrl: '/api' // prod: if backend mounted under /api
};
