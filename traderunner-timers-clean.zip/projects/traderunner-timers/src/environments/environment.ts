export const environment = {
  production: false,
  apiBaseUrl: '' // dev: use proxy for '/timers'
};
