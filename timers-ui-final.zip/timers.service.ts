import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({ providedIn: 'root' })
export class TimersService {
  private baseUrl = '/timers';

  constructor(private http: HttpClient) {}

  getAll(): Promise<any[]> {
    return this.http.get<any[]>(this.baseUrl).toPromise();
  }

  create(timer: any): Promise<any> {
    return this.http.post<any>(this.baseUrl, timer).toPromise();
  }

  update(id: string, timer: any): Promise<any> {
    return this.http.put<any>(`${this.baseUrl}/${id}`, timer).toPromise();
  }

  suspend(ids: string[]): Promise<string> {
    return this.http.post(`${this.baseUrl}/suspend`, ids, { responseType: 'text' }).toPromise();
  }

  resume(ids: string[]): Promise<string> {
    return this.http.post(`${this.baseUrl}/resume`, ids, { responseType: 'text' }).toPromise();
  }

  trigger(ids: string[]): Promise<string> {
    return this.http.post(`${this.baseUrl}/trigger`, ids, { responseType: 'text' }).toPromise();
  }
}
