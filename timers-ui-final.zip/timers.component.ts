import { Component, OnInit } from '@angular/core';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatDialog } from '@angular/material/dialog';
import { ColDef, GetContextMenuItemsParams, MenuItemDef } from 'ag-grid-community';
import { TimersService } from './timers.service';
import { ConfirmDialogComponent } from './confirm-dialog.component';

@Component({
  selector: 'app-timers',
  templateUrl: './timers.component.html',
  styleUrls: ['./timers.component.scss']
})
export class TimersComponent implements OnInit {
  rowData: any[] = [];
  columnDefs: ColDef[] = [
    { field: 'name', headerName: 'Name' },
    { field: 'timeZone', headerName: 'Time Zone' },
    { field: 'triggerTime', headerName: 'Trigger Time' },
    { field: 'active', headerName: 'Active', valueFormatter: p => p.value ? 'Yes' : 'No' }
  ];

  gridOptions = {
    rowSelection: 'multiple',
    getContextMenuItems: (params: GetContextMenuItemsParams): (string | MenuItemDef)[] => {
      const selected = params.api.getSelectedRows();
      const multiple = selected.length > 1;
      const result: (string | MenuItemDef)[] = ['copy', 'separator'];
      if (selected.length > 0) {
        if (!multiple) {
          result.push({
            name: 'Trigger',
            action: () => this.confirmAndRun('trigger', selected.map(r => r.name))
          });
        }
        result.push({
          name: 'Suspend',
          action: () => this.confirmAndRun('suspend', selected.map(r => r.name))
        });
        result.push({
          name: 'Resume',
          action: () => this.confirmAndRun('resume', selected.map(r => r.name))
        });
      }
      return result;
    }
  };

  constructor(private timersService: TimersService, private snackBar: MatSnackBar, private dialog: MatDialog) {}

  ngOnInit(): void {
    this.load();
  }

  load(): void {
    this.timersService.getAll().then(data => this.rowData = data);
  }

  private confirmAndRun(action: 'suspend' | 'resume' | 'trigger', ids: string[]): void {
    const dialogRef = this.dialog.open(ConfirmDialogComponent, {
      data: { action, ids }
    });
    dialogRef.afterClosed().subscribe(result => {
      if (result === 'confirm') {
        let op: Promise<string>;
        switch (action) {
          case 'suspend': op = this.timersService.suspend(ids); break;
          case 'resume': op = this.timersService.resume(ids); break;
          case 'trigger': op = this.timersService.trigger(ids); break;
        }
        op.then(msg => {
          this.snackBar.open(msg, 'Close', { duration: 3000 });
          this.load();
        }).catch(err => {
          this.snackBar.open('Error: ' + err.message, 'Close', { duration: 3000 });
        });
      }
    });
  }
}
