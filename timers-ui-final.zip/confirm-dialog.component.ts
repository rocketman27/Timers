import { Component, Inject } from '@angular/core';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-confirm-dialog',
  template: `
    <h2 mat-dialog-title>Confirm Action</h2>
    <mat-dialog-content>Are you sure you want to {{data.action}} timer(s): {{data.ids.join(', ')}}?</mat-dialog-content>
    <mat-dialog-actions align="end">
      <button mat-button (click)="onDismiss()">Dismiss</button>
      <button mat-button color="primary" (click)="onConfirm()">Confirm</button>
    </mat-dialog-actions>
  `
})
export class ConfirmDialogComponent {
  constructor(
    public dialogRef: MatDialogRef<ConfirmDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { action: string, ids: string[] }
  ) {}

  onConfirm(): void {
    this.dialogRef.close('confirm');
  }

  onDismiss(): void {
    this.dialogRef.close();
  }
}
