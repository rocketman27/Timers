import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { Timer } from '../models/timer.model';

@Injectable({ providedIn: 'root' })
export class TimerService {
  private http = inject(HttpClient);
  private baseUrl = '/api/timers';

  getTimers(): Observable<Timer[]> {
    return this.http.get<{ _embedded?: { timers?: Timer[] } }>(this.baseUrl).pipe(
      map(res => res._embedded?.timers ?? [])
    );
  }

  addTimer(timer: Timer): Observable<Timer> {
    return this.http.post<Timer>(this.baseUrl, timer);
  }

  deleteTimer(id: string): Observable<void> {
    return this.http.delete<void>(\`\${this.baseUrl}/\${encodeURIComponent(id)}\`);
  }

  suspendTimer(id: string): Observable<void> {
    return this.http.post<void>(\`\${this.baseUrl}/\${encodeURIComponent(id)}/suspend\`, {});
  }

  resumeTimer(id: string): Observable<void> {
    return this.http.post<void>(\`\${this.baseUrl}/\${encodeURIComponent(id)}/resume\`, {});
  }

  triggerTimer(id: string): Observable<void> {
    return this.http.post<void>(\`\${this.baseUrl}/\${encodeURIComponent(id)}/trigger\`, {});
  }
}
