import { Component, OnInit } from '@angular/core';
import { TimersStore } from '../../core/store/timers.store';

@Component({
  selector: 'app-timers',
  templateUrl: './timers.component.html',
  providers: [TimersStore],
})
export class TimersComponent implements OnInit {
  timers$ = this.store.timers$;
  loading$ = this.store.loading$;
  error$ = this.store.error$;
  lastMessage$ = this.store.lastMessage$;

  constructor(private store: TimersStore) {}

  ngOnInit(): void {
    this.store.loadTimers();
  }

  refresh(): void {
    this.store.loadTimers();
  }

  delete(id: string): void {
    this.store.deleteTimer(id);
  }

  suspend(ids: string[]): void {
    this.store.suspendTimers(ids);
  }
}
