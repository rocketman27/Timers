import { Injectable } from '@angular/core';
import { ComponentStore } from '@ngrx/component-store';
import { Timer } from '../models/timer.model';
import { TimersApiService } from '../api/timers-api.service';
import { ApiResponse } from '../models/api-response.model';
import { switchMap, tap } from 'rxjs/operators';
import { Observable } from 'rxjs';

export interface TimersState {
  timers: Timer[];
  loading: boolean;
  error?: string;
  lastMessage?: string;
}

@Injectable()
export class TimersStore extends ComponentStore<TimersState> {
  constructor(private api: TimersApiService) {
    super({ timers: [], loading: false });
  }

  readonly timers$ = this.select(state => state.timers);
  readonly loading$ = this.select(state => state.loading);
  readonly error$ = this.select(state => state.error);
  readonly lastMessage$ = this.select(state => state.lastMessage);

  readonly setLoading = this.updater((state, loading: boolean) => ({
    ...state,
    loading,
  }));

  readonly setTimers = this.updater((state, timers: Timer[]) => ({
    ...state,
    timers,
    loading: false,
    error: undefined,
  }));

  readonly setError = this.updater((state, error: string) => ({
    ...state,
    loading: false,
    error,
  }));

  readonly setMessage = this.updater((state, msg: string) => ({
    ...state,
    lastMessage: msg,
  }));

  readonly loadTimers = this.effect((trigger$: Observable<void>) =>
    trigger$.pipe(
      tap(() => this.setLoading(true)),
      switchMap(() =>
        this.api.getAll().pipe(
          tap({
            next: timers => this.setTimers(timers),
            error: err => this.setError(err.message),
          })
        )
      )
    )
  );

  readonly deleteTimer = this.effect((id$: Observable<string>) =>
    id$.pipe(
      switchMap(id =>
        this.api.delete(id).pipe(
          tap({
            next: (res: ApiResponse) => {
              this.setMessage(res.message);
              this.loadTimers();
            },
            error: err => this.setError(err.message),
          })
        )
      )
    )
  );

  readonly suspendTimers = this.effect((ids$: Observable<string[]>) =>
    ids$.pipe(
      switchMap(ids =>
        this.api.suspend(ids).pipe(
          tap({
            next: res => {
              this.setMessage(res.message);
              this.loadTimers();
            },
            error: err => this.setError(err.message),
          })
        )
      )
    )
  );
}
