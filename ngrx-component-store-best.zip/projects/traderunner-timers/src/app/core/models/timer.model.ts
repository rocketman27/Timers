export interface Timer {
  name: string;
  timeZone: string;
  triggerTime: string;
  publishTime: string;
  active: boolean;
  filterCondition?: {
    regions?: string[];
    subregions?: string[];
    countries?: string[];
    productTypes?: string[];
    bookingModels?: string[];
    flowTypes?: string[];
  };
}
