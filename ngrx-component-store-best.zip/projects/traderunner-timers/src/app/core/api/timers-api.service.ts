import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Timer } from '../models/timer.model';
import { ApiResponse } from '../models/api-response.model';

@Injectable({ providedIn: 'root' })
export class TimersApiService {
  private readonly baseUrl = '/timers';

  constructor(private http: HttpClient) {}

  getAll(): Observable<Timer[]> {
    return this.http.get<Timer[]>(this.baseUrl);
  }

  create(timer: Timer): Observable<Timer> {
    return this.http.post<Timer>(this.baseUrl, timer);
  }

  update(id: string, timer: Timer): Observable<Timer> {
    return this.http.put<Timer>(`${this.baseUrl}/${id}`, timer);
  }

  delete(id: string): Observable<ApiResponse> {
    return this.http.delete<ApiResponse>(`${this.baseUrl}/${id}`);
  }

  suspend(ids: string[]): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.baseUrl}/suspend`, ids);
  }

  resume(ids: string[]): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.baseUrl}/resume`, ids);
  }

  trigger(ids: string[]): Observable<ApiResponse> {
    return this.http.post<ApiResponse>(`${this.baseUrl}/trigger`, ids);
  }
}
